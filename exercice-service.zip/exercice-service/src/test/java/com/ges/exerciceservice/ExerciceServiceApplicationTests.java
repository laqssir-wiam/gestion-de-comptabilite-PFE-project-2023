package com.ges.exerciceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
