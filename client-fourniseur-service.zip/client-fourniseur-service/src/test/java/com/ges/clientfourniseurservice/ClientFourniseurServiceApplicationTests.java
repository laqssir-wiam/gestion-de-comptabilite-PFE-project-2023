package com.ges.clientfourniseurservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientFourniseurServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
