package com.ges.plancomptableservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanComptableServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
