package com.base.basemodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaseModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaseModelApplication.class, args);
	}

}
